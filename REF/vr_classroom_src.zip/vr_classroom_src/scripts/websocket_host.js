
let clientsObj = {};
let socket;
let clientID = "";


function initSocket(){
    
    socket =  io();
    socket.on("connect", ()=>{
        console.log("============ info ===========");
        console.log(socket);
        console.log(socket.id);
        console.log(socket.connected);
        console.log("============ info ===========");

        socket.emit('regist_host', "");
        
        // socket.emit('regist client', 0);
        
    });
    socket.on("disconnect", ()=>{

    });

    socket.on("client_leave", (data)=>{
        const dataArr = data.split(",");
        const leaveID = dataArr[0];
        console.log("Client Leave: " + leaveID);
        getSocketInfo();
    });

    socket.on("regist_host", (data)=>{
        const dataArr = data.split(",");
        clientID = dataArr[0];
        console.log("Regist Host Success: " + clientID);
        getSocketInfo();
        //console.log(dataArr);
    });

    socket.on("regist_client", (data)=>{
        const dataArr = data.split(",");
        const regClient = dataArr[0];
        console.log("Regist Client Success: " + regClient);
        getSocketInfo();
        //console.log(dataArr);
    });

    socket.on("data_from_client", (data)=>{
        const dataArr = data.split(",");



    });

}