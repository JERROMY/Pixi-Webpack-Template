
import {init, animate, onChangeContent} from './index_client.js'

let clientsObj = {};
export let socket;
export let clientID = "";
export let fromID = "";


export function initSocket(){

    socket =  io();
    socket.on("connect", ()=>{
        console.log("============ info Clients ===========");
        console.log(socket);
        console.log(socket.id);
        console.log(socket.connected);
        console.log("============ info Clients ===========");

        socket.emit('regist_client');
        // socket.emit('regist host', 1);
        // socket.emit('regist client', 0);

    });
    socket.on("disconnect", ()=>{

    });
    socket.on("regist_client", (data)=>{

        const dataArr = data.split(",");
        clientID = dataArr[0];
        console.log("Regist Client Success: " + clientID);

        init();
	    //animate();


    });
    socket.on("get_msg_from_host", (data)=>{

        const dataArr = data.split(",");
        fromID = dataArr[0];
        const msgStr = dataArr[1];
        

        onChangeContent(msgStr);


    });


}
