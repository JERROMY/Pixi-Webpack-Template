
$(document).ready(function(){

    console.log("Ready");

    initSocket();
    initEvent();
    resetNumber();

});

function initEvent(){

    $( "#c1" ).click(function() {

        const contentID = 1;
        sendToClients(contentID, "c");
        // $.get( "light/Reset", function( data ) {
        //     console.log(data)
        // });

    });

    //client_count_div
    

    $( "#c2" ).click(function() {

        const contentID = 2;
        sendToClients(contentID, "c");
        // $.get( "light/Reset", function( data ) {
        //     console.log(data)
        // });

    });

    $( "#c3" ).click(function() {

        const contentID = 3;
        sendToClients(contentID, "c");
        // $.get( "light/Reset", function( data ) {
        //     console.log(data)
        // });

    });

    $( "#c4" ).click(function() {

        const contentID = 4;
        sendToClients(contentID, "c");
        // $.get( "light/Reset", function( data ) {
        //     console.log(data)
        // });

    });

    $( "#c5" ).click(function() {

        const contentID = 5;
        sendToClients(contentID, "c");
        // $.get( "light/Reset", function( data ) {
        //     console.log(data)
        // });

    });

    for(let i = 1 ; i <= 9 ; i++){
        $( "#e" + i.toString() ).attr('name', i);
        $( "#e" + i.toString() ).click(function() {

            const clickID = parseInt($( '#' + this.id).attr( "name" ));

            console.log("click emoji");
            console.log(clickID);

            sendToClients(clickID, "e");
            

    
        });
    }

    //document.addEventListener( 'keydown', onDocumentKeyDown, false );
    //document.addEventListener( 'keypress', onDocumentKeyPress, false );
    //document.addEventListener( 'keyup', onDocumentKeyUp, false );


}

function sendToClients(cID, sType){

    const dataStr = cID + "," + sType;
    socket.emit('send_to_all_clients', dataStr);
}

function onDocumentKeyPress(event) {

    console.log(event.key);
    if (event.key == "r") {
        console.log("Press R");
    }
}

function getSocketInfo(){
    $.get( "sockets_info", function( data ) {

        const statusStr = data.toString();
        $( "#client_count_div" ).text(statusStr + " / 10");
        console.log(statusStr);

    });
}

function resetNumber(){
    percentNum = 0;
    let percentStr = percentNum + "%";
    // console.log(percentNum);
    $( "#percent-text" ).text( percentStr );
    $( "#title-text" ).hide();
    $( "#percent-text" ).show();
}

function resultShow(){
    $( "#percent-text" ).fadeOut(1);
    $( "#title-text" ).delay(1).fadeIn();
}

function onDocumentKeyDown(event){
    //console.log("Key Down");
}

function onDocumentKeyUp(event){
    //console.log("Key Up");

}

function QueryString(name) {
    var AllVars = window.location.search.substring(1);
    var Vars = AllVars.split("&");
    for (i = 0; i < Vars.length; i++)
    {
      var Var = Vars[i].split("=");
      if (Var[0] == name) return Var[1];
    }
    return "-1";
}
