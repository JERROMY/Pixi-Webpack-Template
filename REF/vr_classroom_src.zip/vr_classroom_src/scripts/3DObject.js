
import * as THREE from 'three';


export class emoji extends THREE.Group {
    constructor(eType) {
        super();

        this.texture = new THREE.TextureLoader().load( "./images/e"+(eType.toString())+".png" );

        // this.spGeo = new THREE.PlaneGeometry( 2, 2 );
        // this.spMat = new THREE.MeshStandardMaterial( { map: this.texture ,color: 0xffffff, transparent: true, side:THREE.DoubleSide} );
        // this.spMesh = new THREE.Mesh( this.spGeo, this.spMat );

        this.material = new THREE.SpriteMaterial( { map: this.texture, color: 0xffffff } );
        this.sprite = new THREE.Sprite( this.material );
        this.add( this.sprite );

        this.sprite.scale.set(0.2, 0.2, 0.2);

        gsap.to(this.sprite.scale, { x: 2.0, y:2.0, z:2.0, duration: 0.6, ease: "power2.out"});
        gsap.to(this.sprite.scale, { x: 0.0, y:0.0, z:0.0, duration: 0.55, delay:0.65, ease: "power2.out"});
        gsap.to(this.sprite.position, {y: 5, duration: 1.2, ease: "power2.out", onComplete: this.moveComplete, onCompleteParams: [this]});

    }

    moveComplete(effObj){
        console.log("Move OK!");
        effObj.removeFromParent();
    }

    

}


export class Scene extends THREE.Group {
    constructor(sceneName, basePath) {
        super();
        this.loaderMgr = new THREE.LoadingManager(this.loaderMgr);
        this.objLoader = new THREE.ObjectLoader();
        this.basePath = basePath;
        this.sceneName = sceneName;
        this.scenePath = this.basePath;
        this.sceneObjPath = this.basePath + "/" + this.sceneName + ".json";
        this.sceneObj = null;
        this.itemsLoaded = 0;
        this.itemsTotal = 2009344;

        this.count = 0;

        this.clock = new THREE.Clock();

        //Socket
        this.socket;
        this.clientID = "";
        this.fromID;

        this.initEvent();
    }

    initEvent(){

        const self = this;
        this.loaderMgr.onStart = function ( url, itemsLoaded, itemsTotal ) {

            //console.log( 'Started loading file: ' + url + '.\nLoaded ' + itemsLoaded + ' of ' + itemsTotal + ' files.' );

        };

        this.loaderMgr.onLoad = function () {

            console.log("========== Manage Finished ===========");
            //console.log(self.resourceMap);
            //console.log(self.objLoader);

        };


        this.loaderMgr.onProgress = function ( url, itemsLoaded, itemsTotal ) {

            //console.log( 'Loading file: ' + url + '.\nLoaded ' + itemsLoaded + ' of ' + itemsTotal + ' files.' );
            console.log( 'Loaded ' + itemsLoaded + ' of ' + itemsTotal + ' files.' );
            //self.itemsLoaded = itemsLoaded;
            //self.itemsTotal = itemsTotal;
            //self.dispatchEvent({type:"processLoadScene"});

        };

        this.loaderMgr.onError = function ( url ) {


            //console.log( 'There was an error loading ' + url );

        };
    }


    startLoad(loadList){

        console.log("=========== Now Scene Start Load Name ==========");
        console.log("Scene Name: " + this.sceneName);

        const self = this;
        
       this.objLoader.load(this.sceneObjPath, function (obj){

            //console.log(self);
          
            console.log("=========== Scene Loaded ===========");
            self.sceneObj = obj;
            self.sceneFinishLoad();


       },function ( xhr ) {
           //console.log( xhr );
           self.itemsLoaded = xhr.loaded;
           //console.log( (xhr.loaded / xhr.total * 100) + '% loaded' );
           self.dispatchEvent({type:"processLoadScene"});

       });

    }

    sceneFinishLoad(){

        let childNum = this.children.length;
        this.add(this.sceneObj);
        this.sceneObj.rotation.y = - Math.PI / 2;

        if(childNum > 0){
            
            console.log("Load Scene Complete!");
            console.log(this);

            this.createEmoji(2);

            this.initSocket();
        }


        

        //this.cam_cube = this.sceneObj.getObjectByName("CamCube");

        //this.initSocket();

        
    }

    createEmoji(eType){
        const emojiEff = new emoji(eType);
        emojiEff.position.y = 2;
        emojiEff.position.x = Math.random()*2-1;
        this.add(emojiEff);
        
    }

    initSocket(){

        const self = this;

        this.socket =  io();
        this.socket.on("connect", ()=>{
            console.log("============ info Clients ===========");
            console.log(this.socket);
            console.log(this.socket.id);
            console.log(this.socket.connected);
            console.log("============ info Clients ===========");

            this.socket.emit('regist_client');
            // socket.emit('regist host', 1);
            // socket.emit('regist client', 0);

        });
        this.socket.on("disconnect", ()=>{

        });
        this.socket.on("regist_client", (data)=>{

            const dataArr = data.split(",");
            const clientID = dataArr[0];


            if(this.clientID == ""){
                this.clientID = clientID;
                console.log("Regist Client Success: " + this.clientID);
                self.clock = new THREE.Clock();
                this.dispatchEvent({type:"finishLoadScene"});
    
            }else{
                console.log(clientID + " join in !");
            }
           
            //init();
            //animate();


        });

        this.socket.on("get_msg_from_host", (data)=>{

            console.log(data);

            const dataArr = data.split(",");
            this.fromID = dataArr[0];
            const msgStr = dataArr[1];
            const msgType = dataArr[2];

            if(msgType == "c"){

                let cID = parseInt(msgStr) - 1;

                self.sceneObj.children[0].visible = false;
                self.sceneObj.children[1].visible = false;
                self.sceneObj.children[2].visible = false;
                self.sceneObj.children[3].visible = false;
                self.sceneObj.children[4].visible = false;


                self.sceneObj.children[cID].visible = true;

            }else if(msgType == "e"){

                let eID = parseInt(msgStr);

                self.createEmoji(eID);

            }

            // console.log(self.clientID + ": " + msgStr);

            


        });
    }



    update(){
        //console.log("update");

        const delta = this.clock.getDelta();
        gsap.ticker.tick(delta);


        this.count += 0.01;
        if(this.count >= 360){
            this.count = 0;
        }
        this.sceneObj.rotation.y = - Math.PI / 2 + Math.sin(this.count);

    }


}

