

//let clientName = "MarkerDataSet2";

// import { initSocket, clientID } from './websocket_client.js'


import * as THREE from 'three';
import { Scene } from './3DObject.js';
import { OrbitControls } from './threejs_n/jsm/controls/OrbitControls.js';
// import { CSS2DRenderer, CSS2DObject } from './threejs_n/jsm/renderers/CSS2DRenderer.js';
import { VRButton } from './threejs_n/jsm/webxr/VRButton.js';
import { XRControllerModelFactory } from './threejs_n/jsm/webxr/XRControllerModelFactory.js';
import { XRHandModelFactory } from './threejs_n/jsm/webxr/XRHandModelFactory.js';

let container;
let camera, scene, renderer;
let controls;

let hand1, hand2;
let controller1, controller2;
let controllerGrip1, controllerGrip2;
let nowS;

let sceneBaseDir = "assets/";


$(document).ready(function(){

    console.log("Ready");
    checkStatus();

});

function checkStatus(){
    //initSocket();
    init();
    initEvent();
}

function initEvent(){
    $( "#press" ).click(function() {

        socket.emit('send_to_host', dataStr);

    });

}

function startLoading(sName){

    let loadList = [];
    const exS = new Scene(sName, sceneBaseDir);
    nowS = exS;


    exS.addEventListener("processLoadScene", function (e){
        let s = e.target;
        let itemsLoaded = s.itemsLoaded;
        let itemsTotal = s.itemsTotal;
        console.log(s.itemsLoaded + " / " + s.itemsTotal);



    })

    exS.addEventListener("finishLoadScene", function(e){

        //console.log("Scene Name: " + exS.sceneName +  " Status: finish Load!");
        //console.log(exS.sceneObj);
        
        exS.scale.set(0.5, 0.5, 0.5);
        //exS.rotation.y = -Math.PI/3;
        exS.position.z = -5;
        exS.sceneObj.children[0].visible = true;
        scene.add(exS);

        // raycasterObjs = exS.walls;
        // raycasterObjs = raycasterObjs.concat(exS.exObjs);
        //console.log(raycasterObjs);



        //resizeWindow();
        //setTimeout(startEnterScene(), 1000);

        animate();

    })
    exS.startLoad(loadList);
}

function init(){

    container = document.getElementById( 'container' );
    camera = new THREE.PerspectiveCamera( 50, window.innerWidth / window.innerHeight, 0.1, 1000 );
	camera.position.set( 0, 1.6, 3 );
    
    scene = new THREE.Scene();
	scene.background = new THREE.Color( 0x444444 );

    //

    controls = new OrbitControls( camera, container );
    controls.target.set( 0, 1.6, 0 );
    controls.update();

    const floorGeometry = new THREE.PlaneGeometry( 12, 12 );
    const floorMaterial = new THREE.MeshStandardMaterial( { color: 0x222222 } );
    const floor = new THREE.Mesh( floorGeometry, floorMaterial );
    floor.rotation.x = - Math.PI / 2;
    floor.receiveShadow = true;
    scene.add( floor );

    scene.add( new THREE.HemisphereLight( 0x808080, 0x606060 ) );

    const light = new THREE.DirectionalLight( 0xffffff );
    light.position.set( 0, 6, 0 );
    light.castShadow = true;
    light.shadow.camera.top = 2;
    light.shadow.camera.bottom = - 2;
    light.shadow.camera.right = 2;
    light.shadow.camera.left = - 2;
    light.shadow.mapSize.set( 4096, 4096 );
    scene.add( light );

    //
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio( window.devicePixelRatio );
    renderer.setSize( window.innerWidth, window.innerHeight );
    renderer.outputEncoding = THREE.sRGBEncoding;
	renderer.shadowMap.enabled = true;
	renderer.xr.enabled = true;
    container.appendChild( renderer.domElement );

    document.body.appendChild( VRButton.createButton( renderer ) );


    addController();

    window.addEventListener( 'resize', onWindowResize );

    startLoading("ani");

    //const material = new THREE.MeshBasicMaterial( { map: texture, color: 0xffffff} );

}

function addController(){


    // controllers

    controller1 = renderer.xr.getController( 0 );
    scene.add( controller1 );

    controller2 = renderer.xr.getController( 1 );
    scene.add( controller2 );

    const controllerModelFactory = new XRControllerModelFactory();
    const handModelFactory = new XRHandModelFactory();

    // Hand 1
    controllerGrip1 = renderer.xr.getControllerGrip( 0 );
    controllerGrip1.add( controllerModelFactory.createControllerModel( controllerGrip1 ) );
    scene.add( controllerGrip1 );

    hand1 = renderer.xr.getHand( 0 );
    hand1.add( handModelFactory.createHandModel( hand1 ) );

    scene.add( hand1 );

    // Hand 2
    controllerGrip2 = renderer.xr.getControllerGrip( 1 );
    controllerGrip2.add( controllerModelFactory.createControllerModel( controllerGrip2 ) );
    scene.add( controllerGrip2 );

    hand2 = renderer.xr.getHand( 1 );
    hand2.add( handModelFactory.createHandModel( hand2 ) );
    scene.add( hand2 );

    //

    const geometry = new THREE.BufferGeometry().setFromPoints( [ new THREE.Vector3( 0, 0, 0 ), new THREE.Vector3( 0, 0, - 1 ) ] );

    const line = new THREE.Line( geometry );
    line.name = 'line';
    line.scale.z = 5;

    controller1.add( line.clone() );
    controller2.add( line.clone() );

    //
}

function onWindowResize() {

    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize( window.innerWidth, window.innerHeight );

}

export function animate() {

    renderer.setAnimationLoop( render );

}

function render() {


    if(nowS != null){
        nowS.update();
    }

    renderer.render( scene, camera );

}

function QueryString(name) {
    var AllVars = window.location.search.substring(1);
    var Vars = AllVars.split("&");
    for (i = 0; i < Vars.length; i++)
    {
      var Var = Vars[i].split("=");
      if (Var[0] == name) return Var[1];
    }
    return "-1";
}
