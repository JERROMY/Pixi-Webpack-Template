
$(document).ready(function(){

    console.log("Ready");

    //initSocket();

    checkStatus();

});

function checkStatus(){
    $.get( "phase", function( data ) {

        const statusStr = data.toString();

        if(statusStr == "wait"){
            $( "#start" ).text("活動尚未開始");
        }

        if(statusStr == "start"){
            $( "#start" ).text("點擊活動開始");
            initEvent();
        }

    });
}

function initEvent(){

    $( "#start" ).click(function() {

       location.href = 'index_client.html';

    });

}

function QueryString(name) {
    var AllVars = window.location.search.substring(1);
    var Vars = AllVars.split("&");
    for (i = 0; i < Vars.length; i++)
    {
      var Var = Vars[i].split("=");
      if (Var[0] == name) return Var[1];
    }
    return "-1";
}
