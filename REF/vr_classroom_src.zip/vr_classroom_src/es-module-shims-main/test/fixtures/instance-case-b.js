import { common } from "./instance-case-common.js";

window.common_b = common;
