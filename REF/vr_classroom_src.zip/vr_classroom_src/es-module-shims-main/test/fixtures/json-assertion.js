import json from './json.json' assert { type: 'json' };

export const m = json.json;