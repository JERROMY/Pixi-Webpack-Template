// This comment should not be affected by the sourceMappingURL replacement: //# sourceMappingURL=i-should-not-be-affected.no
export const answer: number = 42;
