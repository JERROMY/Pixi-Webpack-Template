export { b, c } from './c.js';
export { a } from './a.js';
export var s = 's';
ordering.push('s');