// This comment should not be affected by the sourceURL replacement: //# sourceURL=i-should-not-be-affected.no
export const answer = 42;

//# sourceURL=module.ts