export default 'dynamic';
window.dynamic = true;
