export const answer = 42;
