import { p } from "./relative-path" // Expecting ./es6-dep.js

const a = 'a'

export { p, a }
