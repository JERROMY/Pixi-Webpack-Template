// This comment should not be affected by the sourceMappingURL replacement: //# sourceMappingURL=i-should-not-be-affected.no
export var answer = 42;
//# sourceMappingURL=with-relative-source-mapping-url.js.map