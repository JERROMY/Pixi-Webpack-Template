export * from './export-star.js';
export function foo() {
  
}