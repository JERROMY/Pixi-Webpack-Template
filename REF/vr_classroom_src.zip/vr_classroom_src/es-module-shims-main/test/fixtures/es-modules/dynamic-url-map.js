export default 'dynamic url map';
window.dynamicUrlMap = true;
