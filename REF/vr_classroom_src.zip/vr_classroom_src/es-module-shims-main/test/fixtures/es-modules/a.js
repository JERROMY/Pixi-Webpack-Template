export { b } from './b.js';
export var a = 'a';
ordering.push('a');