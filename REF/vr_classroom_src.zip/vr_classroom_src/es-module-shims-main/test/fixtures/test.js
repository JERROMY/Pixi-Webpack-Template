export { hello as default } from "test-dep";
