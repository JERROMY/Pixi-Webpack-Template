import { g } from './test-circular1.js';

export default g();