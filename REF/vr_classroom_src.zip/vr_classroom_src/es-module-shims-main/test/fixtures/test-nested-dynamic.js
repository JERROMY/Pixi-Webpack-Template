export default import(`data:text/javascript,export default "${import.meta.url}"`);
