import { f } from './test-circular1.js';

export function g () {
  return f();
}