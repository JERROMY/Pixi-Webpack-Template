export default import('./test-dep.js');
